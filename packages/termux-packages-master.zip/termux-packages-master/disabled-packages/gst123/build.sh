# Broken - requires gtk
TERMUX_PKG_HOMEPAGE=http://space.twc.de/~stefan/gst123.php
TERMUX_PKG_DESCRIPTION="GStreamer based command line media player"
TERMUX_PKG_VERSION=0.3.4
TERMUX_PKG_SRCURL=http://space.twc.de/~stefan/gst123/gst123-${TERMUX_PKG_VERSION}.tar.bz2
TERMUX_PKG_DEPENDS="gst-plugins-bad, ncurses"
