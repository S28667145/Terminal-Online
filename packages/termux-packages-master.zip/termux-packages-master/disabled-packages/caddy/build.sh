TERMUX_PKG_HOMEPAGE=https://github.com/mholt/caddy
TERMUX_PKG_DESCRIPTION="Fast, cross-platform HTTP/2 web server with automatic HTTPS"
TERMUX_PKG_VERSION=0.8.0
TERMUX_PKG_SRCURL=https://github.com/mholt/caddy/archive/v${TERMUX_PKG_VERSION}.tar.gz
