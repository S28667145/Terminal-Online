TERMUX_PKG_HOMEPAGE=http://www.gnu.org/software/guile/
TERMUX_PKG_DESCRIPTION="GNU extension language and Scheme interpreter"
TERMUX_PKG_VERSION=2.0.11
TERMUX_PKG_SRCURL=ftp://ftp.gnu.org/gnu/guile/guile-${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_DEPENDS="libgmp, libunistring, libffi, libgc"
