# Disabled due to source download failing.

# using a snapshot tarball because blogc-0.13.0 is not ready for release yet
# (documentation updates pending), but it is already useful and stable enough

TERMUX_PKG_HOMEPAGE=https://blogc.rgm.io/
TERMUX_PKG_DESCRIPTION="A blog compiler"
TERMUX_PKG_VERSION=0.12.0.123.acf1
TERMUX_PKG_REVISION=1
TERMUX_PKG_MAINTAINER="Rafael Martins @rafaelmartins"
TERMUX_PKG_SRCURL="https://travis-distfiles.rgm.io/blogc/blogc-0.12.0.123-acf1/blogc-0.12.0.123-acf1.tar.xz"
TERMUX_PKG_SHA256=c1885fd8d0068cb24fda899a236591af9daf492aec3601690e7d9a7badf97616
TERMUX_PKG_EXTRA_CONFIGURE_ARGS="--disable-git-receiver --enable-make --enable-runserver --disable-tests --disable-valgrind"
