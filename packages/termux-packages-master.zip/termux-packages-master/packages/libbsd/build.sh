TERMUX_PKG_HOMEPAGE=https://libbsd.freedesktop.org
TERMUX_PKG_DESCRIPTION="utility functions from BSD systems"
TERMUX_PKG_VERSION=0.9.1
TERMUX_PKG_SRCURL=https://libbsd.freedesktop.org/releases/libbsd-$TERMUX_PKG_VERSION.tar.xz
TERMUX_PKG_SHA256=56d835742327d69faccd16955a60b6dcf30684a8da518c4eca0ac713b9e0a7a4
TERMUX_PKG_BUILD_IN_SRC=yes
