TERMUX_PKG_HOMEPAGE=http://libpipeline.nongnu.org/
TERMUX_PKG_DESCRIPTION="C library for manipulating pipelines of subprocesses in a flexible and convenient way"
TERMUX_PKG_VERSION=1.5.0
TERMUX_PKG_SHA256=0d72e12e4f2afff67fd7b9df0a24d7ba42b5a7c9211ac5b3dcccc5cd8b286f2b
TERMUX_PKG_SRCURL=http://download.savannah.gnu.org/releases/libpipeline/libpipeline-${TERMUX_PKG_VERSION}.tar.gz
