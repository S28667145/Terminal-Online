TERMUX_PKG_HOMEPAGE=http://software.schmorp.de/pkg/libev.html
TERMUX_PKG_DESCRIPTION="Full-featured and high-performance event loop library"
TERMUX_PKG_VERSION=4.24
TERMUX_PKG_SHA256=973593d3479abdf657674a55afe5f78624b0e440614e2b8cb3a07f16d4d7f821
TERMUX_PKG_SRCURL=https://fossies.org/linux/misc/libev-$TERMUX_PKG_VERSION.tar.gz
