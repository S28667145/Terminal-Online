TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Fast LZ compression algorithm tool"
TERMUX_SUBPKG_DEPENDS="liblz4"
