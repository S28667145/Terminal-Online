TERMUX_PKG_HOMEPAGE=https://www.opus-codec.org/
TERMUX_PKG_DESCRIPTION="Reference implementation of the Opus codec"
TERMUX_PKG_VERSION=1.3
TERMUX_PKG_SHA256=4f3d69aefdf2dbaf9825408e452a8a414ffc60494c70633560700398820dc550
TERMUX_PKG_SRCURL=https://archive.mozilla.org/pub/opus/opus-${TERMUX_PKG_VERSION}.tar.gz
