TERMUX_PKG_HOMEPAGE=http://www.nongnu.org/lzip/
TERMUX_PKG_DESCRIPTION="Lossless data compressor similar to gzip and bzip2"
TERMUX_PKG_VERSION=1.20
TERMUX_PKG_REVISION=1
TERMUX_PKG_SHA256=f719f64ab9c59fd4b8c8f88e824f9332b4ff53f2e50d1c36deb4ee2e790c5dfa
TERMUX_PKG_SRCURL=http://download.savannah.gnu.org/releases/lzip/lzip-${TERMUX_PKG_VERSION}.tar.lz
