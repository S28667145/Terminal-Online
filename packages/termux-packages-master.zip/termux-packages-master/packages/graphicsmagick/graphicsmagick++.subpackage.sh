TERMUX_SUBPKG_INCLUDE="lib/libGraphicsMagick++.so"
TERMUX_SUBPKG_DESCRIPTION="format-independent image processing - C++ shared library"
TERMUX_SUBPKG_DEPENDS="graphicsmagick"
