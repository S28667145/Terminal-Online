TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Command line shell for SQLite"
TERMUX_SUBPKG_DEPENDS="libsqlite, readline"
