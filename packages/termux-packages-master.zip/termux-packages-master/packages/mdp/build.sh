TERMUX_PKG_HOMEPAGE=https://github.com/visit1985/mdp
TERMUX_PKG_DESCRIPTION=" A command-line based markdown presentation tool."
TERMUX_PKG_MAINTAINER='lokesh @hax4us'
TERMUX_PKG_VERSION=1.0.15
TERMUX_PKG_SHA256=3edc8ea1551fdf290d6bba721105e2e2c23964070ac18c13b4b8d959cdf6116f
TERMUX_PKG_SRCURL=https://github.com/visit1985/mdp/archive/${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_DEPENDS="ncurses"
TERMUX_PKG_BUILD_IN_SRC=yes
