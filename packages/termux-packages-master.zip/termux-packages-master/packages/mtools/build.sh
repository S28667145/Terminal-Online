TERMUX_PKG_HOMEPAGE=https://www.gnu.org/software/mtools/
TERMUX_PKG_DESCRIPTION="Tool for manipulating FAT images."
TERMUX_PKG_VERSION=4.0.19
TERMUX_PKG_SHA256=1bc197199ea1c2c317f597879486eeb817f3199b526d94cc6841624768d910df
TERMUX_PKG_SRCURL=ftp://ftp.gnu.org/gnu/mtools/mtools-${TERMUX_PKG_VERSION}.tar.bz2
TERMUX_PKG_DEPENDS="libandroid-support"

