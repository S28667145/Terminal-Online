TERMUX_PKG_HOMEPAGE=https://www.gnu.org/software/ddrescue/
TERMUX_PKG_DESCRIPTION="GNU data recovery tool"
TERMUX_PKG_VERSION=1.23
TERMUX_PKG_REVISION=1
TERMUX_PKG_SHA256=a9ae2dd44592bf386c9c156a5dacaeeb901573c9867ada3608f887d401338d8d
TERMUX_PKG_SRCURL=https://mirrors.kernel.org/gnu/ddrescue/ddrescue-${TERMUX_PKG_VERSION}.tar.lz
