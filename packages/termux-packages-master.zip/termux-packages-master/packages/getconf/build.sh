TERMUX_PKG_HOMEPAGE=https://github.com/termux/getconf
TERMUX_PKG_DESCRIPTION="Utility to print configuration values"
TERMUX_PKG_VERSION=0.5
TERMUX_PKG_SHA256=8192701051d2a2bf8d1ae7b1c0922c3f1d4a039b9ad99496636b0122667d595c
TERMUX_PKG_SRCURL=https://github.com/termux/getconf/archive/v${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_BUILD_IN_SRC=yes
