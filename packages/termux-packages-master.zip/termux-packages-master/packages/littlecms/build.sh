TERMUX_PKG_HOMEPAGE=http://www.littlecms.com/
TERMUX_PKG_DESCRIPTION="Color management library"
TERMUX_PKG_VERSION=2.9
TERMUX_PKG_SHA256=48c6fdf98396fa245ed86e622028caf49b96fa22f3e5734f853f806fbc8e7d20
TERMUX_PKG_SRCURL=https://downloads.sourceforge.net/project/lcms/lcms/${TERMUX_PKG_VERSION}/lcms2-${TERMUX_PKG_VERSION}.tar.gz
