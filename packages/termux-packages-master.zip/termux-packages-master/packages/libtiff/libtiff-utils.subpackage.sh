TERMUX_SUBPKG_INCLUDE="bin share/man"
TERMUX_SUBPKG_DESCRIPTION="Tools for working with tiff files"
TERMUX_SUBPKG_DEPENDS="libtiff"
