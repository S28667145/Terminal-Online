TERMUX_PKG_HOMEPAGE=https://github.com/silnrsi/graphite
TERMUX_PKG_DESCRIPTION="Font system for multiple languages"
TERMUX_PKG_VERSION=1.3.12
TERMUX_PKG_SHA256=2b90cff3e64a37dd4f6fa4ac46c7634f8707601a8b4478f8501c74d3be774366
TERMUX_PKG_SRCURL=https://github.com/silnrsi/graphite/archive/${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_RM_AFTER_INSTALL="bin/gr2fonttest"
